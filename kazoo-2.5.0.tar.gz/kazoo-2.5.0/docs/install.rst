.. _install:

==========
Installing
==========

kazoo can be installed via ``pip``:

.. code-block:: bash

    $ pip install kazoo

Kazoo implements the Zookeeper protocol in pure Python, so you don't need
any Python Zookeeper C bindings installed.
