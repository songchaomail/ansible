import setuptools

setuptools.setup(
    name="requires_wheelbroken_upper",
    version="0",
    install_requires=['wheelbroken', 'upper'])
