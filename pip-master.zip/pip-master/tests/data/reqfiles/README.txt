supported_options.txt
---------------------

Contains --no-use-wheel.

supported_options2.txt
----------------------

Contains --no-binary and --only-binary options.
