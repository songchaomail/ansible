from setuptools import setup
setup(name='withpyproject', version='0.0.1')
