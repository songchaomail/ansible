def spam(gen):
    yield from gen
