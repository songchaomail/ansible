__author__    = "Manuel Maldonado"
__copyright__ = "Copyright 2016, The SAGA Project"
__license__   = "MIT"
