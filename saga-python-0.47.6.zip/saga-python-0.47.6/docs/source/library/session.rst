Sessions
********

.. todo:: Intro to SAGA Session

Session -- :mod:`saga.session`
------------------------------

.. automodule:: saga.session
   :show-inheritance:
   :members: Session

