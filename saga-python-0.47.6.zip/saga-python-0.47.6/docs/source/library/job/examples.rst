
.. _code_examples_job:

Job Module
==========

Basic Job Submission
--------------------

Describe example

:download:`Download Python source for this example.<../../../../examples/jobs/localjob.py>`

.. literalinclude:: ../../../../examples/jobs/localjob.py
   :linenos:


Job Containers
--------------

Describe example

:download:`Download Python source for this example.<../../../../examples/jobs/localjobcontainer.py>`

.. literalinclude:: ../../../../examples/jobs/localjobcontainer.py
   :linenos:
