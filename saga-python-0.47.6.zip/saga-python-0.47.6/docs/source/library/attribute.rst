Attributes and Callbacks
************************

.. todo:: Intro to SAGA attribute interface.


Callbacks -- :class:`saga.Callback`
-----------------------------------

.. autoclass:: saga.attributes.Callback
   :members:


Attribute -- :class:`saga.Attributes`
-------------------------------------

.. autoclass:: saga.attributes.Attributes
   :members:
