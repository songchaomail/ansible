
.. _code_examples_advert:

Advert Module
=============

Basic Replica Management
------------------------

Describe example

:download:`Download Python source for this example.<../../../../examples/advert/advert_1.py>`

.. literalinclude:: ../../../../examples/advert/advert_1.py
   :linenos:

