
.. _code_examples_files:

Filesystem Module
=================

Basic File Manipulations
------------------------

Describe example

:download:`Download Python source for this example.<../../../../examples/filesystem/localfile.py>`

.. literalinclude:: ../../../../examples/filesystem/localfile.py
   :linenos:


File I/O
--------

Describe example

:download:`Download Python source for this example.<../../../../examples/filesystem/file_io.py>`

.. literalinclude:: ../../../../examples/filesystem/file_io.py
   :linenos:

