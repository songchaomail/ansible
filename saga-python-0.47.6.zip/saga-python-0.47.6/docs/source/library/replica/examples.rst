
.. _code_examples_replica:

Replica Module
==============

Basic Replica Management
------------------------

Describe example

:download:`Download Python source for this example.<../../../../examples/replica/replica_1.py>`

.. literalinclude:: ../../../../examples/replica/replica_1.py
   :linenos:

