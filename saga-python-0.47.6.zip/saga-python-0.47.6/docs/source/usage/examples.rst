
*******************************
Getting Started: Usage Examples
*******************************

Point the user to some *simple* examples, to get him started using the new installation / configuration.

